package com.company;

import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {
        BigFractionCalculatorGUI app = new BigFractionCalculatorGUI();
        app.setVisible(true);
    }
}
